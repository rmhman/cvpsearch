"""
CVP Search package initialization
"""
from cvp_search.main import main

__all__ = ['main']